# Library-Managment_Java-Gui
The owner of a library wants to digitalize the process of library management, so help 
him in this process by witing a java program that stores the details(book id, book name, 
author, price) of books in a file, It should be able to add new books to file, Lend books to 
Readers and their details in order to lend books. The reader can search books by book 
name, book id. He wants to do this in proper and easy manner as he feels that compiler 
and terminal inputs are difficult and not easy to understand so, you have to use 
Graphical User Interface  
